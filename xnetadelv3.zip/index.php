<?php
include 'backend/server.php';
?>

<!doctype html>
<html lang="id">
<head>
<link rel="icon" type="image/svg+xml" href="icon.svg">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>XnetAdelV23</title>
<style>
    :root{--bg:#000000;--fg:#ff0000}
    html,body{height:100%;margin:0}

    body{
    font-family:ui-sans-serif,system-ui,Segoe UI,Roboto,'Helvetica Neue',Arial;
    background:url('wallpaper.jpg');
    background-repeat: no-repeat;
    background-size:cover;
    color:var(--fg);
    display:flex;
    align-items:center;
    justify-content:center;
    padding-bottom:120px; /* ruang untuk music bar */
    }

    .card{width:920px;max-width:96%;
    background: transparent;
    box-shadow:none;
    border-radius:12px;
    padding:18px;position:relative;z-index:1}

/* animated red border around the card */
.card::before{
    content:"";
    position:absolute;
    inset:-4px; /* space for the border */
    border-radius:16px;
    background:transparent;
    background-size:300% 100%;
    z-index:0;
    animation: border-move 3s linear infinite;
    -webkit-mask: ox, redt;
    -webkit-mask-composite: xor;
    mask-composite: exclude;
    padding:4px;
}

@keyframes border-move{
    from{background-position:0%}
    to{background-position:100%}
}

.header{
display:flex;
align-items:center;
gap:12px;
margin-bottom:12px;
position:relative;z-index:1
}

.logo{width:44px;height:44px;border-radius:8px;background:#000000;border:2px solid #ff0000;display:flex;align-items:center;justify-content:center;color:var(--fg);font-weight:700}
h1{font-size:18px;margin:0;color:var(--fg)}
p.sub{margin:0;color:var(--fg);opacity:0.9;font-size:13px}

.terminal{background:transparent;color:var(--fg);padding:12px;border-radius:8px;height:360px;overflow:auto;font-family:monospace;font-size:13px;line-height:1.4;border:2px solid transparent;position:relative;z-index:1}
.prompt{display:flex;gap:8px;align-items:center;margin-top:10px;position:relative;z-index:1}
.prompt .prompt-text{font-family:monospace;background:#000000;padding:8px 10px;border-radius:8px;color:var(--fg);flex:1;border:1px solid #ff0000}
.btn{background:#ff0000;color:#000000;padding:8px 12px;border-radius:8px;border:2px solid #ff0000;cursor:pointer;font-weight:600}
.btn:disabled{opacity:0.6;cursor:not-allowed}
.controls{display:flex;gap:8px;align-items:center}
.small{font-size:12px;color:var(--fg);opacity:0.9}
.stderr{color:#ff0000}

/* Ensure nothing uses other colors */
*{box-sizing:border-box}

/* ---------- Music bar styles ---------- */
.music-bar {
  position: fixed;
  left: 12px;
  right: 12px;
  bottom: 12px;
  background: rgba(0,0,0,0.6);
  border: 1px solid rgba(255,0,0,0.6);
  padding: 10px;
  border-radius: 12px;
  display:flex;
  align-items:center;
  gap:12px;
  z-index:9999;
  backdrop-filter: blur(6px);
  color:var(--fg);
}

.music-toggle{
  display:flex;
  align-items:center;
  gap:8px;
  cursor:pointer;
  user-select:none;
}

.music-toggle .dot{
  width:36px;height:36px;border-radius:8px;background:#000;border:2px solid #ff0000;display:flex;align-items:center;justify-content:center;font-weight:700;
}

.playlist {
  display:none;
  width:100%;
  max-width:920px;
  background:transparent;
  border-left:1px dashed rgba(255,0,0,0.12);
  padding-left:12px;
  gap:8px;
  align-items:center;
  justify-content:space-between;
}

.playlist.open{display:flex}

.track-list{
  display:flex;
  gap:8px;
  align-items:center;
  overflow:auto;
  padding:4px 0;
}

.track{
  padding:8px 12px;
  border-radius:8px;
  background:rgba(255,255,255,0.02);
  cursor:pointer;
  white-space:nowrap;
  font-size:14px;
  border:1px solid transparent;
}
.track.active{
  background:rgba(255,0,0,0.12);
  border-color:rgba(255,0,0,0.3);
  color:#fff;
}

.music-controls{
  display:flex;
  gap:8px;
  align-items:center;
}

.icon-btn{
  background:transparent;
  border:1px solid rgba(255,0,0,0.25);
  padding:8px;
  border-radius:8px;
  cursor:pointer;
  color:var(--fg);
  font-weight:600;
}

.progress{
  width:160px;
  height:6px;
  background:rgba(255,255,255,0.06);
  border-radius:6px;
  overflow:hidden;
}
.progress > i{
  display:block;
  height:100%;
  width:0%;
  background:rgba(255,0,0,0.9);
}

/* small screens tweak */
@media (max-width:600px){
  .music-bar{flex-direction:column;align-items:flex-start;padding:10px}
  .playlist{width:100%;border-left:none;padding-left:0}
  .progress{width:100%}
}
</style>
</head>
<body>
<div class="card">
    <div class="header">
        <div>
            <h1>XnetAdel V22</h1>
            <p><strong>Hi, I'm XnetAdel. Wifi Attack Tools </strong></p>
            <p>Pencet start kalo mau jalanin ><</p>
        </div>
    </div><div id="terminal" class="terminal" role="log" aria-live="polite">$ ready. press Start to run node all.js</div>
<div class="prompt">
    <div class="prompt-text">/root/Xnet/Adel &gt;</div>
    <div class="controls">
        <button id="startBtn" class="btn">Start</button>
        <button id="stopBtn" class="btn" style="background:#ef4444">Stop</button>
        <div class="small">Status: <span id="status">idle</span></div>
    </div>
</div>
</div>

<!-- ====== MUSIC BAR (NEW) ====== -->
<div class="music-bar" aria-hidden="false">
  <div class="music-toggle" id="musicToggle" role="button" tabindex="0" aria-pressed="false" title="Toggle playlist">
    <div class="dot">♪</div>
    <div>
      <div style="font-size:14px">Music</div>
      <div class="small" style="opacity:0.8">Klik untuk buka playlist</div>
    </div>
  </div>

  <div class="playlist" id="playlist">
    <div class="track-list" id="trackList" role="list">
      <!-- tracks injected by JS -->
    </div>

    <div style="display:flex;align-items:center;gap:8px">
      <div class="music-controls">
        <button id="prevBtn" class="icon-btn" title="Prev">⏮</button>
        <button id="playPauseBtn" class="icon-btn" title="Play/Pause">▶</button>
        <button id="nextBtn" class="icon-btn" title="Next">⏭</button>
      </div>
      <div class="progress" title="progress"><i id="progBar"></i></div>
    </div>
  </div>

  <!-- Hidden audio element -->
  <audio id="audioPlayer" preload="metadata"></audio>
</div>

<script>
(function(){
    const start = document.getElementById('startBtn');
    const stop = document.getElementById('stopBtn');
    const term = document.getElementById('terminal');
    const status = document.getElementById('status');
    let es = null;
    function appendLine(text, isErr){
        const div = document.createElement('div');
        if (isErr) div.className = 'stderr';
        div.textContent = text;
        term.appendChild(div);
        term.scrollTop = term.scrollHeight;
    }   start.addEventListener('click', ()=>{
        if (es) return;
        appendLine('$ Attack Starting...');
        status.textContent = 'running';
        start.disabled = true;
        stop.disabled = false;
        es = new EventSource(window.location.pathname + '?action=stream');
        es.onmessage = function(e){
            if (e.data === '__PROCESS_FINISHED__'){
                appendLine('$ process finished');
                es.close();
                es = null;
                status.textContent = 'idle';
                start.disabled = false;
                stop.disabled = true;
                return;
            }
            if (e.data.startsWith('[ERR]')){
                appendLine(e.data.replace(/ERR\s*/,'(stderr) '), true);
            } else {
                appendLine(e.data);
            }
        };

        es.onerror = function(ev){
            appendLine('$ connection error or closed');
            if (es) es.close();
            es = null;
            status.textContent = 'idle';
            start.disabled = false;
            stop.disabled = true;
        };
    });

    stop.addEventListener('click', ()=>{
        if (!es) return;
        appendLine('$ requested stop (closing stream)');
        es.close();
        es = null;
        status.textContent = 'idle';
        start.disabled = false;
        stop.disabled = true;
    });

    stop.disabled = true;
})();
</script>

<script>
/* --------- Music player logic --------- */
(function(){
  const tracks = [
    { title: 'Slay x Enough! - Eternxlkz', src: 'music/song1.mp3' },
    { title: 'Enough - Eternxlkz', src: 'music/song2.mp3' },
    { title: 'Next! - NCTS', src: 'music/song3.mp3' }
  ];
  // If you don't have local files, ganti path di atas ke URL atau file yang ada.

  const audio = document.getElementById('audioPlayer');
  const trackListEl = document.getElementById('trackList');
  const playlistEl = document.getElementById('playlist');
  const toggle = document.getElementById('musicToggle');
  const playPauseBtn = document.getElementById('playPauseBtn');
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  const progBar = document.getElementById('progBar');

  let current = -1;
  let isPlaying = false;

  // render track buttons
  tracks.forEach((t, i) => {
    const el = document.createElement('div');
    el.className = 'track';
    el.setAttribute('role','listitem');
    el.textContent = t.title;
    el.dataset.index = i;
    el.addEventListener('click', ()=> playIndex(i));
    trackListEl.appendChild(el);
  });

  function highlight(){
    const nodes = trackListEl.querySelectorAll('.track');
    nodes.forEach(n => n.classList.remove('active'));
    if (current >=0) nodes[current].classList.add('active');
  }

  function playIndex(i){
    if (i < 0 || i >= tracks.length) return;
    const t = tracks[i];
    if (!t.src){
      alert('File lagu tidak ditemukan: ' + t.title);
      return;
    }
    current = i;
    audio.src = t.src;
    audio.play().catch(e=>{
      console.warn('play failed', e);
      // autoplay might be blocked by browser; change UI only
      isPlaying = false;
      playPauseBtn.textContent = '▶';
    });
    isPlaying = true;
    playPauseBtn.textContent = '⏸';
    highlight();
  }

  function togglePlaylist(){
    const open = playlistEl.classList.toggle('open');
    toggle.setAttribute('aria-pressed', open ? 'true' : 'false');
  }

  function togglePlayPause(){
    if (!audio.src && tracks.length) {
      playIndex(0);
      return;
    }
    if (audio.paused) {
      audio.play();
      isPlaying = true;
      playPauseBtn.textContent = '⏸';
    } else {
      audio.pause();
      isPlaying = false;
      playPauseBtn.textContent = '▶';
    }
  }

  function prev(){
    if (current <= 0) playIndex(tracks.length - 1);
    else playIndex(current - 1);
  }
  function next(){
    if (current >= tracks.length - 1) playIndex(0);
    else playIndex(current + 1);
  }

  // events
  toggle.addEventListener('click', togglePlaylist);
  toggle.addEventListener('keypress', (e)=> { if (e.key === 'Enter') togglePlaylist(); });
  playPauseBtn.addEventListener('click', togglePlayPause);
  prevBtn.addEventListener('click', prev);
  nextBtn.addEventListener('click', next);

  audio.addEventListener('ended', ()=> {
    // auto next
    next();
  });

  audio.addEventListener('timeupdate', ()=>{
    if (!audio.duration || isNaN(audio.duration)) return;
    const pct = (audio.currentTime / audio.duration) * 100;
    progBar.style.width = pct + '%';
  });

  // allow clicking on progress to seek
  const progressWrap = progBar.parentElement;
  progressWrap.addEventListener('click', (e)=>{
    const rect = progressWrap.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const pct = x / rect.width;
    if (audio.duration) audio.currentTime = pct * audio.duration;
  });

  // init highlight if needed
  highlight();

  // optional: keyboard shortcuts
  window.addEventListener('keydown', (e)=>{
    if (e.key === ' ' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA'){
      e.preventDefault();
      togglePlayPause();
    } else if (e.key === 'ArrowRight') next();
    else if (e.key === 'ArrowLeft') prev();
  });
})();
</script>

</body>
</html>
